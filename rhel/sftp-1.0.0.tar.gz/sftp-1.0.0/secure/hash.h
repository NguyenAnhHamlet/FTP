#ifndef __HASH__ 
#define __HASH__ 

void sha256(char* in, int inlen, char** out, int *outlen );

#endif